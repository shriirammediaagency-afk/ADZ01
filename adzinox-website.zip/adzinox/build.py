#!/usr/bin/env python3
"""Assemble src/* into dist/index.html (standalone), dist/404.html and dist/adzinox-artifact.html (fragment)."""
import pathlib, re

root = pathlib.Path(__file__).parent
src = root / "src"
dist = root / "dist"
dist.mkdir(exist_ok=True)

head = (src / "head.html").read_text()
css = (src / "style.css").read_text()
body = (src / "body.html").read_text()
js = (src / "data.js").read_text() + "\n" + (src / "app.js").read_text()

LIBS = """
<!-- Libraries (pinned versions from public CDNs) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lenis@1.1.13/dist/lenis.min.js"></script>
"""

# Fragment for Claude's artifact viewer (it adds the html/head/body wrapper itself)
fragment = f"{head}\n<style>\n{css}\n</style>\n{body}\n{LIBS}\n<script>\n{js}\n</script>\n"
(dist / "adzinox-artifact.html").write_text(fragment)

# Standalone production file
head_clean = head.replace('<meta name="claude:viewport-fit-sides" content="cover">\n', "")
def standalone(start=""):
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
{head_clean}
<style>
{css}
</style>
</head>
<body>
{body}
{LIBS}
{start}<script>
{js}
</script>
</body>
</html>
"""
(dist / "index.html").write_text(standalone())
(dist / "404.html").write_text(standalone('<script>window.ADZ_START="page-404";</script>\n'))

# helper: standalone JS for syntax checking
(root / "dist" / "_check.js").write_text(js)
print("built:", [p.name for p in sorted(dist.iterdir())])
