/* ============================================================
   3. APP
============================================================ */
(() => {
'use strict';

/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const root = document.documentElement;
const body = document.body;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
const hasGSAP = typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const safe = fn => { try { return fn(); } catch (e) { return null; } };
const store = { get: k => safe(() => localStorage.getItem(k)), set: (k, v) => safe(() => localStorage.setItem(k, v)) };
let lenis = null;
let lastSec = 'home';

/* ---------- inline SVG icons (24x24, stroke) ---------- */
const ICONS = {
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',
  trend: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
  pen: '<path d="M4 20l4-1 11-11a2.1 2.1 0 0 0-3-3L5 16l-1 4z"/><path d="M14 7l3 3"/>',
  film: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9.5v5l4.5-2.5z"/>',
  star: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M17 4.5l.9 1.9 2.1.3-1.5 1.5.4 2.1-1.9-1-1.9 1 .4-2.1L14 6.7l2.1-.3z"/>',
  starf: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  billboard: '<rect x="3" y="4" width="18" height="10" rx="1.5"/><path d="M8 14v6M16 14v6M7 9h10"/>',
  code: '<path d="M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14"/>',
  text: '<path d="M5 4h14M5 9h14M5 14h9M5 19h6"/>',
  megaphone: '<path d="M3 11v2a1 1 0 0 0 1 1h3l8 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M18 9a4 4 0 0 1 0 6"/>',
  chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4M10 12h4"/>',
  cart: '<circle cx="9" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/><path d="M3 4h3l2.5 11h9L20 8H7"/>',
  bag: '<path d="M5 8h14l-1 12H6z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  fork: '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 3c-2 2-2.5 5-2.5 8H17v10"/>',
  health: '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c3 2 9 2 12 0v-4.5"/>',
  building: '<rect x="5" y="3" width="10" height="18"/><path d="M15 9h4v12h-4M8 7h4M8 11h4M8 15h4"/>',
  rupee: '<path d="M7 5h10M7 9h10M7 5c6 0 6 8 0 8h-.5L14 20"/>',
  car: '<path d="M4 16v-4l2-5h12l2 5v4zM4 16v2M20 16v2"/><circle cx="8" cy="14" r=".8"/><circle cx="16" cy="14" r=".8"/>',
  shirt: '<path d="M8 3l-5 4 3 3 2-1v12h8V9l2 1 3-3-5-4a4 4 0 0 1-8 0z"/>',
  plane: '<path d="M2 13l20-8-8 16-2-7z"/>',
  tv: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8M12 18v3"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
  compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5L13.5 13.5 8.5 15.5 10.5 10.5z"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 17v4M17 19h4"/>',
  rocket: '<path d="M5 19c0-3 2-4 2-4l2 2s-1 2-4 2zM9 15l-1-1c1-5 5-10 12-11-1 7-6 11-11 12z"/><circle cx="15" cy="9" r="1.2"/>',
  loop: '<path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4v5h-5"/>',
  pin: '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  heart: '<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H4v1a3 3 0 0 0 3 3M16 6h4v1a3 3 0 0 1-3 3M12 13v4M8 20h8M10 17h4"/>',
  instagram: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".8"/>',
  linkedin: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 10v7M8 7v.01M12 17v-4a2.5 2.5 0 0 1 5 0v4M12 10v7"/>',
  facebook: '<path d="M14 21v-8h3l.5-3.5H14V7.5c0-1 .4-1.7 1.8-1.7H18V2.7A22 22 0 0 0 15.3 2.5C12.9 2.5 11 4 11 6.9v2.6H8V13h3v8z"/>',
  youtube: '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10.5 9.5v5l4-2.5z"/>',
  x: '<path d="M4 4l16 16M20 4L4 20"/>',
  whatsapp: '<path d="M3 21l1.6-4.9A8.5 8.5 0 1 1 8 19.6z"/><path d="M9 9c0 3 3 6 6 6l1.2-1.5-2-1-1 .7c-1-.5-1.7-1.2-2.2-2.2l.7-1-1-2z"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  send: '<path d="M3 11l18-8-8 18-2-8z"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h10"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'
};
const ic = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;
function hydrateIcons(r = document) {
  $$('i[data-ic]', r).forEach(i => {
    const t = document.createElement('template');
    t.innerHTML = ic(i.dataset.ic);
    const s = t.content.firstChild;
    if (i.getAttribute('style')) s.setAttribute('style', i.getAttribute('style'));
    i.replaceWith(s);
  });
}

/* ---------- images: gradient placeholder first, real Unsplash photo swaps in when it loads ---------- */
const ph = (label) => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 560"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0b1030"/><stop offset=".55" stop-color="#2a1366"/><stop offset="1" stop-color="#5b0f55"/></linearGradient></defs><rect width="800" height="560" fill="url(#g)"/><g stroke="#22e5ff" stroke-opacity=".18"><path d="M0 140H800M0 280H800M0 420H800M200 0V560M400 0V560M600 0V560"/></g><circle cx="560" cy="170" r="120" fill="#ff2fd0" fill-opacity=".18"/><circle cx="260" cy="380" r="150" fill="#22e5ff" fill-opacity=".14"/><text x="400" y="290" fill="#fff" fill-opacity=".85" font-family="monospace" font-size="26" text-anchor="middle">PLACEHOLDER IMAGE</text><text x="400" y="330" fill="#fff" fill-opacity=".55" font-family="monospace" font-size="20" text-anchor="middle">${label}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
};
// ✎ REPLACE: put your own images in the project and point data-src at them
const img = (id, alt, w, h, label = 'replace with your image') =>
  `<img src="${ph(label)}" data-src="https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70" alt="${alt}" width="${w}" height="${h}" loading="lazy" decoding="async">`;
const loadReal = el => { const u = el.dataset.src; if (!u) return; const t = new Image(); t.onload = () => { el.src = u; }; t.src = u; };
const imgIO = 'IntersectionObserver' in window
  ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { imgIO.unobserve(e.target); loadReal(e.target); } }), { rootMargin: '400px 400px' })
  : null;
const lazy = (r = document) => $$('img[data-src]', r).forEach(i => { if (i.dataset.l) return; i.dataset.l = 1; imgIO ? imgIO.observe(i) : loadReal(i); });

/* ---------- bind config ---------- */
function bindConfig() {
  const digits = CONFIG.phone.replace(/[^\d+]/g, '');
  $$('[data-bind]').forEach(el => { el.textContent = CONFIG[el.dataset.bind]; });
  $$('[data-href="tel"]').forEach(el => { el.href = 'tel:' + digits; });
  $$('[data-href="mailto"]').forEach(el => { el.href = 'mailto:' + CONFIG.email; });
  $$('[data-wa]').forEach(el => {
    el.href = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent('Hi Adzinox, I would like to discuss a project.')}`;
    el.target = '_blank'; el.rel = 'noopener';
  });
  $('#yr').textContent = new Date().getFullYear();
  $$('.demo-note').forEach(n => { n.hidden = !!CONFIG.formEndpoint; });
  if (CONFIG.showPlaceholderTags) body.classList.add('show-ph');
  const q = encodeURIComponent(CONFIG.mapQuery);
  $('#map-link').href = `https://www.google.com/maps/search/?api=1&query=${q}`;
  // Live map embed (iframes cannot load inside Claude's artifact viewer, but work on your own hosting)
  if (!window.claude) {
    const f = document.createElement('iframe');
    f.src = `https://www.google.com/maps?q=${q}&output=embed`;
    f.title = 'Adzinox location on Google Maps'; f.loading = 'lazy'; f.referrerPolicy = 'no-referrer-when-downgrade';
    $('#map').prepend(f);
  }
}

/* ---------- renderers ---------- */
const social = (cls = '') => ['instagram', 'linkedin', 'facebook', 'youtube', 'x']
  .map(k => `<a href="${CONFIG.social[k]}" target="_blank" rel="noopener" aria-label="Adzinox on ${k === 'x' ? 'X' : k[0].toUpperCase() + k.slice(1)}">${ic(k)}</a>`).join('');

function renderStatic() {
  // nav menu
  $('#menu-grid').innerHTML = SECTIONS.map(([id, l], i) => `<a href="#${id}"><small>${String(i + 1).padStart(2, '0')}</small>${l}</a>`).join('');
  // about
  $('#values').innerHTML = VALUES.map(v => `<article class="card value" data-reveal data-tilt>${ic(v.ic)}<h3>${v.t}</h3><p>${v.d}</p></article>`).join('');
  $('#timeline').innerHTML = TIMELINE.map(([y, t]) => `<li><b>${y}</b><span>${t}</span></li>`).join('');
  // services
  $('#svc-grid').innerHTML = SERVICES.map(s => `
    <article class="card svc" data-reveal data-tilt data-service="${s.id}" style="cursor:pointer">
      <div class="svc-ic">${ic(s.ic)}</div>
      <h3>${s.t}</h3><p>${s.s}</p>
      <div class="svc-tags">${s.tags.map(t => `<span class="chip">${t}</span>`).join('')}</div>
      <button class="svc-go" type="button" data-service="${s.id}" aria-label="Learn more about ${s.t}">Learn more ${ic('arrow')}</button>
    </article>`).join('');
  // process
  $('#steps').innerHTML = STEPS.map((s, i) => `
    <li class="step" data-reveal><span class="step-dot">${ic(s.ic)}</span><small>Step ${i + 1}</small><h3>${s.t}</h3><p>${s.d}</p></li>`).join('');
  // stats
  $('#stats').innerHTML = STATS.map(s => `
    <div class="card stat ph-flag" data-reveal><b data-count="${s.n}" data-p="${s.p}" data-s="${s.s}" data-d="${s.d}">${s.p}${s.n.toFixed(s.d)}${s.s}</b><span>${s.l}</span></div>`).join('');
  // industries
  $('#ind-grid').innerHTML = INDUSTRIES.map(([i, n]) => `<div class="card ind" data-reveal data-tilt>${ic(i)}<span>${n}</span></div>`).join('');
  // clients marquee
  const pills = list => list.map(n => `<div class="logo-pill"><i></i>${n}</div>`).join('');
  const row = (list, id) => { $(id).innerHTML = `<div class="m-track">${pills(list)}<span style="display:contents" data-dup>${pills(list)}</span></div>`; };
  row(CLIENTS, '#mq1'); row([...CLIENTS].reverse(), '#mq2');
  // team
  $('#team-grid').innerHTML = TEAM.map(m => `
    <article class="card member ph-flag" data-reveal data-tilt>
      <div class="member-img">${img(m.img, 'Portrait of ' + m.n + ', ' + m.r, 480, 528, 'team portrait')}</div>
      <div class="member-b"><h3>${m.n}</h3><span>${m.r}</span><div class="socials">${['linkedin', 'instagram', 'x'].map(k => `<a href="${CONFIG.social[k]}" target="_blank" rel="noopener" aria-label="${m.n} on ${k}">${ic(k)}</a>`).join('')}</div></div>
    </article>`).join('');
  // pricing
  $('#price-grid').innerHTML = PLANS.map(p => `
    <article class="card plan ${p.hot ? 'hot' : ''} ph-flag" data-reveal data-tilt>
      ${p.hot ? '<span class="badge">MOST POPULAR</span>' : ''}
      <div><h3>${p.n}</h3><p class="muted" style="font-size:.92rem;margin-top:.3rem">${p.d}</p></div>
      <div class="amt">${p.a} <small>${p.per}</small></div>
      <ul>${p.f.map(f => `<li>${ic('check')}<span>${f}</span></li>`).join('')}</ul>
      <a class="btn ${p.hot ? 'btn--primary' : 'btn--ghost'}" href="#quote" data-quote-plan="${p.n}">${p.a === 'Custom' ? 'Talk to us' : 'Choose ' + p.n}</a>
    </article>`).join('');
  // tools & awards
  $('#tools').innerHTML = TOOLS.map(([n, m]) => `<div class="card tool" data-reveal><i>${m}</i>${n}</div>`).join('');
  $('#awards').innerHTML = AWARDS.map(([t, s]) => `<div class="card award ph-flag" data-reveal>${ic('trophy')}<div><b>${t}</b><span>${s}</span></div></div>`).join('');
  // testimonials
  $('#tstage').innerHTML = TESTIMONIALS.map(t => `
    <figure class="card tcard ph-flag" style="margin:0">
      <div class="stars" role="img" aria-label="5 out of 5 stars">${ic('starf').repeat(5)}</div>
      <blockquote>${t.q}</blockquote>
      <figcaption class="who">${img(t.img, 'Photo of ' + t.n, 104, 104, 'portrait')}<div><b>${t.n}</b><span>${t.r}</span></div></figcaption>
    </figure>`).join('');
  $('#t-dots').innerHTML = TESTIMONIALS.map((t, i) => `<button type="button" aria-label="Show testimonial ${i + 1}"></button>`).join('');
  // careers
  $('#jobs').innerHTML = JOBS.map((j, i) => `
    <div class="card job ph-flag" data-reveal>
      <div><h3>${j.t}</h3><div class="tags"><span class="chip">${j.ty}</span><span class="chip">${j.lo}</span><span class="chip">${j.ex}</span></div></div>
      <button class="btn btn--ghost btn--sm" type="button" data-apply="${i}">Apply ${ic('arrow')}</button>
    </div>`).join('');
  $('#j-role').innerHTML = '<option value="">Select a role</option>' + JOBS.map(j => `<option>${j.t}</option>`).join('') + '<option>Open application</option>';
  // faq
  $('#faq-list').innerHTML = FAQS.map(([q, a], i) => `
    <div class="card faq-i" data-reveal>
      <h3><button class="faq-q" type="button" id="fq${i}" aria-expanded="false" aria-controls="fa${i}"><span>${q}</span>${ic('plus')}</button></h3>
      <div class="faq-a" id="fa${i}" role="region" aria-labelledby="fq${i}" inert><div><p>${a}</p></div></div>
    </div>`).join('');
  // quote service select
  $('#q-service').innerHTML = '<option value="">Select a service</option>' + SERVICES.map(s => `<option>${s.t}</option>`).join('') + '<option>Not sure, advise me</option>';
  // blog preview
  $('#blog-grid').innerHTML = POSTS.slice(0, 3).map((p, i) => postCard(p, i)).join('');
  // footer
  $('#foot-social').innerHTML = social();
  $('#foot-links').innerHTML = SECTIONS.filter(s => ['about', 'work', 'pricing', 'insights', 'careers', 'faq', 'contact'].includes(s[0])).map(([id, l]) => `<li><a href="#${id}">${l}</a></li>`).join('');
  $('#foot-svc').innerHTML = SERVICES.slice(0, 7).map(s => `<li><button type="button" data-service="${s.id}">${s.t}</button></li>`).join('') + '<li><a href="#services">All services</a></li>';
  // FAQ schema markup
  const ld = document.createElement('script'); ld.type = 'application/ld+json';
  ld.textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: FAQS.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) });
  document.head.appendChild(ld);
}

function postCard(p, i) {
  return `<article class="card post ph-flag" data-reveal data-post="${i}" tabindex="0" role="button" aria-label="Read article: ${p.t}" style="cursor:pointer">
    <div class="post-img">${img(p.img, p.t, 640, 400, 'article cover')}</div>
    <div class="post-b"><div class="meta"><b>${p.cat}</b><span>${p.date}</span><span>${p.min} min read</span></div><h3>${p.t}</h3><p>${p.x}</p></div></article>`;
}

/* ---------- portfolio ---------- */
const pcard = (p, i) => `<article class="pcard ph-flag" tabindex="0" role="button" data-project="${i}" aria-label="Open project: ${p.t}">
  ${img(p.img, p.t + ' campaign visual', 800, 560, 'project visual')}
  <div class="pcard-b"><span>${p.c} · ${p.y}</span><h3>${p.t}</h3><p>${p.so.split('.')[0]}.</p></div></article>`;

function renderPortfolio() {
  $('#hs-track').innerHTML = PROJECTS.slice(0, 5).map((p, i) => `<div class="hs-item">${pcard(p, i)}</div>`).join('');
  $('#filters').innerHTML = ['All', ...CATS].map((c, i) => `<button class="filter" type="button" data-filter="${c}" aria-pressed="${i === 0}">${c}</button>`).join('');
  // skeletons first, then content
  $('#pgrid').innerHTML = Array.from({ length: 6 }, () => '<div class="sk"></div>').join('');
  setTimeout(() => drawGrid('All', false), reduce ? 0 : 450);
}
function drawGrid(cat, animate = true) {
  const g = $('#pgrid');
  const list = PROJECTS.map((p, i) => [p, i]).filter(([p]) => cat === 'All' || p.c === cat);
  g.innerHTML = list.map(([p, i]) => pcard(p, i)).join('');
  enhance(g);
  if (animate && hasGSAP && !reduce) gsap.from($$('.pcard', g), { opacity: 0, y: 30, scale: .96, duration: .6, stagger: .06, ease: 'power3.out', clearProps: 'all' });
}

/* ---------- modal / views / locking ---------- */
const modal = $('#modal'), mBody = $('#modal-body'), view = $('#view'), vBody = $('#view-body'), menu = $('#menu');
let lockN = 0, lastFocus = null, viewOpen = null;
const lock = () => { if (++lockN === 1) { body.classList.add('lock'); lenis && lenis.stop(); } };
const unlock = () => { lockN = Math.max(0, lockN - 1); if (!lockN) { body.classList.remove('lock'); lenis && lenis.start(); } };

function openModal(html) {
  lastFocus = document.activeElement;
  mBody.innerHTML = html; enhance(mBody);
  modal.hidden = false; lock();
  requestAnimationFrame(() => modal.classList.add('open'));
  $('.m-close', modal).focus({ preventScroll: true });
  $('.m-panel', modal).scrollTop = 0;
}
function closeModal() {
  if (modal.hidden) return;
  modal.classList.remove('open');
  setTimeout(() => { modal.hidden = true; }, 260);
  unlock();
  lastFocus && lastFocus.focus && lastFocus.focus({ preventScroll: true });
}
const li = items => items.map(x => `<li>${ic('check')}<span>${x}</span></li>`).join('');

function serviceModal(id) {
  const s = SERVICES.find(x => x.id === id); if (!s) return;
  openModal(`<div class="m-body">
    <div class="m-meta"><span class="chip">Service</span>${s.tags.map(t => `<span class="chip">${t}</span>`).join('')}</div>
    <h2 id="modal-title">${s.t}</h2><p>${s.d}</p>
    <h4>What you get</h4><ul>${li(s.g)}</ul>
    <h4>Typical outcome</h4><p>${s.r}</p>
    <div class="m-actions"><button class="btn btn--primary" type="button" data-act="quote" data-service-pick="${s.t}">Discuss this service ${ic('arrow')}</button><button class="btn btn--ghost" type="button" data-act="close">Close</button></div>
  </div>`);
}
function projectModal(i) {
  const p = PROJECTS[i]; if (!p) return;
  openModal(`<div class="m-hero ph-flag">${img(p.img, p.t + ' campaign visual', 1000, 440, 'project hero')}</div>
  <div class="m-body">
    <div class="m-meta"><span class="chip">${p.c}</span><span class="chip">${p.y}</span></div>
    <h2 id="modal-title">${p.t}</h2>
    <h4>The challenge</h4><p>${p.ch}</p>
    <h4>Our solution</h4><p>${p.so}</p>
    <h4>Results</h4><div class="res">${p.res.map(([n, l]) => `<div><b class="grad-text">${n}</b><span>${l}</span></div>`).join('')}</div>
    <p class="note" style="margin:0">✎ REPLACE: sample case study.</p>
    <div class="m-actions"><button class="btn btn--primary" type="button" data-act="quote" data-service-pick="">Start a similar project ${ic('arrow')}</button><button class="btn btn--ghost" type="button" data-act="close">Close</button></div>
  </div>`);
}
function postModal(i) {
  const p = POSTS[i]; if (!p) return;
  openModal(`<div class="m-hero">${img(p.img, p.t, 1000, 440, 'article cover')}</div>
  <div class="m-body"><div class="m-meta"><span class="chip">${p.cat}</span><span class="chip">${p.date}</span><span class="chip">${p.min} min read</span></div>
    <h2 id="modal-title">${p.t}</h2>${p.b.map(t => `<p>${t}</p>`).join('')}
    <div class="m-actions"><button class="btn btn--primary" type="button" data-act="quote" data-service-pick="">Talk to a strategist ${ic('arrow')}</button><button class="btn btn--ghost" type="button" data-act="close">Close</button></div>
  </div>`);
}

const legal = (title, blocks) => `<div class="legal"><p class="eyebrow">Legal</p><h2>${title}</h2>
  <p class="note" style="margin:0">✎ REPLACE: this is a starter template, not legal advice. Have it reviewed for your business before launch.</p>
  ${blocks.map(([h, t]) => `<h3>${h}</h3><p>${t}</p>`).join('')}</div>`;
const VIEWS = {
  'all-articles': () => `<div class="sec-head"><p class="eyebrow">Blog &amp; insights</p><h2>All articles</h2><p class="lead">Notes from the Adzinox team on performance, creative, outdoor and AI.</p></div><div class="blog-grid">${POSTS.map(postCard).join('')}</div>`,
  privacy: () => legal('Privacy Policy', [
    ['What we collect', 'When you use our forms we collect the details you enter, such as your name, email, phone number and message. We also use basic analytics to understand how the site is used.'],
    ['How we use it', 'We use your details to respond to your enquiry, send requested updates and improve our services. We do not sell personal data.'],
    ['Cookies', 'Essential cookies keep the site working. Optional cookies for analytics are used only if you accept them in the cookie banner.'],
    ['Your choices', `You can ask us to access, correct or delete your data by writing to ${CONFIG.email}.`]]),
  terms: () => legal('Terms & Conditions', [
    ['Use of this site', 'The content on this site is provided for general information about Adzinox Private Limited and its services.'],
    ['Services', 'Work is carried out under a written proposal or agreement. Prices on this site are indicative and exclude applicable taxes and media spend.'],
    ['Intellectual property', 'Site content, design and brand assets belong to Adzinox Private Limited or its licensors and may not be reused without permission.'],
    ['Contact', `Questions about these terms can be sent to ${CONFIG.email}.`]]),
  'page-404': () => `<div class="nf"><b data-t="404">404</b><h2>This page drifted off-air.</h2><p>The link you followed does not exist or has moved. Let's get you back to something that does.</p><a class="btn btn--primary" href="#home">Back to home</a></div>`
};

const wipe = $('#wipe');
function transition(cb) {
  if (reduce || !hasGSAP) { cb(); return; }
  gsap.timeline()
    .set(wipe, { transformOrigin: 'bottom', scaleY: 0 })
    .to(wipe, { scaleY: 1, duration: .45, ease: 'power3.inOut' })
    .add(cb)
    .set(wipe, { transformOrigin: 'top' })
    .to(wipe, { scaleY: 0, duration: .5, ease: 'power3.inOut' });
}
function showView(name) {
  if (viewOpen === name || !VIEWS[name]) return;
  const wasOpen = !!viewOpen;
  transition(() => {
    vBody.innerHTML = VIEWS[name](); enhance(vBody);
    view.hidden = false; view.scrollTop = 0;
    if (!wasOpen) lock();
    viewOpen = name;
    requestAnimationFrame(() => view.classList.add('open'));
    $('#view-x').focus({ preventScroll: true });
  });
}
function hideView(restoreHash = true) {
  if (!viewOpen) return;
  transition(() => {
    view.classList.remove('open'); view.hidden = true; viewOpen = null; unlock();
  });
  if (restoreHash) safe(() => history.replaceState(null, '', '#' + lastSec));
}
function route() {
  const h = location.hash.slice(1);
  if (VIEWS[h]) showView(h); else if (viewOpen) hideView(false);
}

/* ---------- smooth scroll to section ---------- */
function go(id, instant) {
  const el = id === 'home' ? document.body : document.getElementById(id);
  if (!el) return;
  safe(() => history.replaceState(null, '', '#' + id));
  const y = id === 'home' ? 0 : el;
  if (lenis && !instant) lenis.scrollTo(y, { offset: id === 'home' ? 0 : -70, duration: 1.4 });
  else if (id === 'home') window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  else el.scrollIntoView({ behavior: reduce || instant ? 'auto' : 'smooth', block: 'start' });
}

/* ---------- forms ---------- */
const RULES = {
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) || 'Enter a valid email, like name@company.com.',
  tel: v => /^(\+?91|0)?[6-9]\d{9}$/.test(v.replace(/[\s\-()]/g, '')) || 'Enter a 10-digit Indian mobile number.',
  url: v => !v || /^https?:\/\/\S+\.\S+/.test(v) || 'Start the link with https://',
  file: (v, el) => !el.files[0] || el.files[0].size < 5 * 1024 * 1024 || 'Choose a file under 5 MB.'
};
function validateField(wrap) {
  const el = $('input,select,textarea', wrap); const err = $('.err', wrap);
  const v = (el.value || '').trim(); let msg = '';
  if (el.required && !v) msg = el.tagName === 'SELECT' ? 'Please choose an option.' : 'This field is required.';
  else if (v || el.type === 'file') {
    const r = RULES[el.type]; if (r) { const out = r(v, el); if (out !== true) msg = out; }
    if (!msg && el.tagName === 'TEXTAREA' && el.required && v.length < 10) msg = 'Add a few more details, at least 10 characters.';
  }
  wrap.classList.toggle('bad', !!msg);
  el.setAttribute('aria-invalid', msg ? 'true' : 'false');
  err.textContent = msg; err.id = err.id || el.id + '-e';
  el.setAttribute('aria-describedby', err.id);
  return !msg;
}
async function submitData(form) {
  const data = new FormData(form);
  if (CONFIG.formEndpoint) {
    const r = await fetch(CONFIG.formEndpoint, { method: 'POST', body: data, headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error('bad status');
  } else await sleep(900); // demo mode: nothing is sent
}
function bindForm(form, { wrap, title, text, inline }) {
  const fields = $$('.field', form);
  fields.forEach(f => {
    const el = $('input,select,textarea', f);
    el.addEventListener('blur', () => { if (el.value || f.classList.contains('bad')) validateField(f); });
    el.addEventListener('input', () => { if (f.classList.contains('bad')) validateField(f); });
    el.addEventListener('change', () => { if (f.classList.contains('bad')) validateField(f); });
  });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const bad = fields.filter(f => !validateField(f));
    if (bad.length) { $('input,select,textarea', bad[0]).focus(); return; }
    const btn = $('button[type=submit]', form); const label = btn.innerHTML;
    btn.disabled = true; btn.textContent = 'Sending…';
    let fe = $('.form-err', form); if (fe) fe.textContent = '';
    try { await submitData(form); } catch (er) {
      btn.disabled = false; btn.innerHTML = label; hydrateIcons(btn);
      if (!fe) { fe = document.createElement('div'); fe.className = 'err form-err'; fe.setAttribute('role', 'alert'); btn.after(fe); }
      fe.textContent = 'Something went wrong while sending. Please try again or message us on WhatsApp.'; return;
    }
    const nm = ($('[name=name]', form) || {}).value || '';
    const box = document.createElement('div'); box.className = 'success'; box.setAttribute('role', 'status');
    box.innerHTML = `<div class="success-ic"><span class="ring"></span><svg viewBox="0 0 92 92" aria-hidden="true"><circle cx="46" cy="46" r="40"/><path d="M28 47l12 12 25-27"/></svg></div><h3></h3><p class="muted"></p><button class="btn btn--ghost btn--sm" type="button">${inline ? 'Use another email' : 'Send another'}</button>`;
    $('h3', box).textContent = nm ? `${title}, ${nm.split(' ')[0]}.` : `${title}.`;
    $('p', box).textContent = text;
    form.hidden = true; (inline ? form.parentElement : wrap).appendChild(box);
    $('button', box).addEventListener('click', () => { box.remove(); form.reset(); fields.forEach(f => f.classList.remove('bad')); btn.disabled = false; btn.innerHTML = label; hydrateIcons(btn); form.hidden = false; });
    if (hasGSAP && !reduce) gsap.from(box, { scale: .9, opacity: 0, duration: .6, ease: 'back.out(1.6)' });
  });
}

/* ---------- enhancements for (re)rendered content ---------- */
function enhance(r = document) {
  hydrateIcons(r); lazy(r);
  if (CONFIG.showPlaceholderTags) $$('.ph-flag:not([data-pt])', r).forEach(e => { e.dataset.pt = 1; e.insertAdjacentHTML('afterbegin', '<em class="ph-tag">SAMPLE</em>'); });
  $$('.card:not([data-sp])', r).forEach(c => {
    c.dataset.sp = 1;
    c.addEventListener('pointermove', e => { const b = c.getBoundingClientRect(); c.style.setProperty('--mx', (e.clientX - b.left) + 'px'); c.style.setProperty('--my', (e.clientY - b.top) + 'px'); });
  });
  if (hasGSAP && fine && !reduce) {
    $$('[data-tilt]:not([data-tl])', r).forEach(c => {
      c.dataset.tl = 1;
      c.addEventListener('pointermove', e => { const b = c.getBoundingClientRect(); const px = (e.clientX - b.left) / b.width - .5, py = (e.clientY - b.top) / b.height - .5; gsap.to(c, { rotationY: px * 9, rotationX: -py * 9, transformPerspective: 900, duration: .4, ease: 'power2.out', overwrite: 'auto' }); });
      c.addEventListener('pointerleave', () => gsap.to(c, { rotationX: 0, rotationY: 0, duration: .6, ease: 'power3.out', overwrite: 'auto' }));
    });
    $$('[data-magnetic]:not([data-mg])', r).forEach(m => {
      m.dataset.mg = 1;
      m.addEventListener('pointermove', e => { const b = m.getBoundingClientRect(); gsap.to(m, { x: (e.clientX - b.left - b.width / 2) * .3, y: (e.clientY - b.top - b.height / 2) * .35, duration: .35, ease: 'power2.out' }); });
      m.addEventListener('pointerleave', () => gsap.to(m, { x: 0, y: 0, duration: .7, ease: 'elastic.out(1,.4)' }));
    });
    // image distortion on hover
    const dmap = $('#distort-map');
    $$('.pcard:not([data-ds])', r).forEach(c => {
      c.dataset.ds = 1; const im = $('img', c);
      c.addEventListener('pointerenter', () => { im.style.filter = 'url(#distort)'; gsap.to(dmap, { attr: { scale: 26 }, duration: .6, ease: 'power2.out', overwrite: true }); });
      c.addEventListener('pointerleave', () => gsap.to(dmap, { attr: { scale: 0 }, duration: .5, ease: 'power2.out', overwrite: true, onComplete: () => { im.style.filter = ''; } }));
    });
  }
  if (hasGSAP && root.classList.contains('anim')) {
    const els = $$('[data-reveal]:not([data-rv])', r);
    els.forEach(e => { e.dataset.rv = 1; });
    if (els.length) ScrollTrigger.batch(els, { start: 'top 92%', once: true, onEnter: b => gsap.to(b, { opacity: 1, y: 0, duration: .85, stagger: .08, ease: 'power3.out', overwrite: true }) });
  }
}

/* ============================================================
   4. INTERACTIONS
============================================================ */
function initTheme() {
  const btn = $('#theme');
  const set = t => {
    root.setAttribute('data-theme', t);
    btn.innerHTML = ic(t === 'light' ? 'moon' : 'sun');
    btn.setAttribute('aria-label', t === 'light' ? 'Switch to dark theme' : 'Switch to light theme');
    store.set('adz-theme', t);
  };
  set(store.get('adz-theme') || root.getAttribute('data-theme') || 'dark');
  btn.addEventListener('click', () => set(root.getAttribute('data-theme') === 'light' ? 'dark' : 'light'));
}

function initNav() {
  const mBtn = $('#menu-btn');
  const open = () => { lastFocus = document.activeElement; menu.hidden = false; lock(); mBtn.setAttribute('aria-expanded', 'true'); requestAnimationFrame(() => menu.classList.add('open')); $('#menu-x').focus({ preventScroll: true }); };
  const close = () => { if (menu.hidden) return; menu.classList.remove('open'); mBtn.setAttribute('aria-expanded', 'false'); setTimeout(() => { menu.hidden = true; }, 300); unlock(); };
  mBtn.addEventListener('click', open); $('#menu-x').addEventListener('click', close);
  menu.addEventListener('click', e => { if (e.target.closest('a')) close(); });
  initNav.close = close;
  // active link + last section
  const links = $$('#nav-links a');
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { lastSec = e.target.id; links.forEach(a => a.classList.toggle('on', a.getAttribute('href') === '#' + e.target.id)); }
  }), { rootMargin: '-45% 0px -50% 0px' });
  $$('main section[id]').forEach(s => io.observe(s));
  // scroll progress, back-to-top
  const prog = $('#progress'), top = $('#to-top');
  const onScroll = () => {
    const h = root.scrollHeight - innerHeight;
    prog.style.transform = `scaleX(${h > 0 ? Math.min(1, scrollY / h) : 0})`;
    top.classList.toggle('show', scrollY > 700);
  };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  top.addEventListener('click', () => go('home'));
}

function initCursor() {
  if (!fine || reduce) return;
  body.classList.add('has-cursor');
  const dot = $('#cur-dot'), ring = $('#cur-ring'), trail = $$('.cur-t');
  let mx = innerWidth / 2, my = innerHeight / 2, rx = mx, ry = my;
  const tp = trail.map(() => ({ x: mx, y: my }));
  addEventListener('pointermove', e => { mx = e.clientX; my = e.clientY; }, { passive: true });
  document.addEventListener('pointerover', e => ring.classList.toggle('hot', !!e.target.closest('a,button,[role=button],.card,input,select,textarea')));
  (function loop() {
    rx += (mx - rx) * .18; ry += (my - ry) * .18;
    dot.style.transform = `translate(${mx}px,${my}px)`;
    ring.style.transform = `translate(${rx}px,${ry}px)`;
    let px = mx, py = my;
    trail.forEach((t, i) => { const p = tp[i]; p.x += (px - p.x) * (.32 - i * .06); p.y += (py - p.y) * (.32 - i * .06); t.style.transform = `translate(${p.x}px,${p.y}px)`; t.style.opacity = (.7 - i * .15).toFixed(2); px = p.x; py = p.y; });
    requestAnimationFrame(loop);
  })();
}

function initTestimonials() {
  const cards = $$('#tstage .tcard'), dots = $$('#t-dots button'), n = cards.length;
  let a = 0, timer = null;
  const layout = () => {
    const narrow = innerWidth < 760;
    cards.forEach((c, i) => {
      let off = i - a; if (off > n / 2) off -= n; if (off < -n / 2) off += n;
      const abs = Math.abs(off), hide = abs > 1 || (narrow && abs > 0);
      c.style.transform = `translateX(${off * (narrow ? 0 : 58)}%) translateZ(${-abs * 170}px) rotateY(${-off * 26}deg) scale(${1 - abs * .06})`;
      c.style.opacity = hide ? 0 : (abs ? .5 : 1); c.style.zIndex = 10 - abs;
      c.style.pointerEvents = abs ? 'none' : 'auto'; c.inert = abs > 0; c.setAttribute('aria-hidden', abs ? 'true' : 'false');
    });
    dots.forEach((d, i) => d.setAttribute('aria-current', i === a ? 'true' : 'false'));
  };
  const go2 = i => { a = (i + n) % n; layout(); };
  $('#t-prev').addEventListener('click', () => { go2(a - 1); restart(); });
  $('#t-next').addEventListener('click', () => { go2(a + 1); restart(); });
  dots.forEach((d, i) => d.addEventListener('click', () => { go2(i); restart(); }));
  $('#tcar').addEventListener('keydown', e => { if (e.key === 'ArrowLeft') { go2(a - 1); restart(); } if (e.key === 'ArrowRight') { go2(a + 1); restart(); } });
  const stop = () => clearInterval(timer);
  const restart = () => { stop(); if (!reduce) timer = setInterval(() => go2(a + 1), 6500); };
  ['mouseenter', 'focusin'].forEach(ev => $('#tcar').addEventListener(ev, stop));
  ['mouseleave', 'focusout'].forEach(ev => $('#tcar').addEventListener(ev, restart));
  addEventListener('resize', layout);
  layout(); restart();
}

function initFAQ() {
  $$('.faq-i').forEach(item => {
    const q = $('.faq-q', item), a = $('.faq-a', item);
    q.addEventListener('click', () => {
      const open = !item.classList.contains('open');
      item.classList.toggle('open', open); q.setAttribute('aria-expanded', open); a.inert = !open;
      if (hasGSAP) setTimeout(() => ScrollTrigger.refresh(), 450);
    });
  });
  const first = $('.faq-i'); if (first) { first.classList.add('open'); $('.faq-q', first).setAttribute('aria-expanded', 'true'); $('.faq-a', first).inert = false; }
}

function initChat() {
  const btn = $('#chat-btn'), panel = $('#chat'), log = $('#chat-log'), input = $('#chat-in'), quick = $('#chat-quick');
  const KB = [
    [/hi\b|hello|hey|namaste/i, 'Hi! I can point you to the right service, pricing or the quote form. What are you looking for?'],
    [/service|offer|what do you do/i, 'We cover brand strategy, digital marketing, social media, creative design, video, influencer marketing, outdoor, web and app development, content, PR and AI analytics. Which one interests you?'],
    [/price|cost|package|budget|rate/i, 'We have Starter, Growth and Enterprise packages, plus custom quotes. Check the Pricing section or share your budget in the quote form.'],
    [/quote|consult|call|meeting|project/i, 'Great. Fill in the Free Quote form and a strategist will follow up. You can also message us on WhatsApp.'],
    [/career|job|hiring|vacanc|intern/i, 'We are hiring. The Careers section lists open roles and has an application form.'],
    [/contact|phone|email|address|whatsapp|where/i, `You can reach us at ${CONFIG.email} or ${CONFIG.phone}. Our studio details are in the Contact section.`]
  ];
  const say = (t, who) => { const b = document.createElement('div'); b.className = 'bub ' + who; b.textContent = t; log.appendChild(b); log.scrollTop = log.scrollHeight; };
  const reply = async t => {
    say(t, 'me'); await sleep(550);
    const hit = KB.find(([re]) => re.test(t));
    say(hit ? hit[1] : 'Good question. A strategist can answer that best. Use the quote form or tap the WhatsApp button and we will pick it up.', 'bot');
  };
  ['Services', 'Pricing', 'Free quote', 'Careers'].forEach(q => { const b = document.createElement('button'); b.type = 'button'; b.textContent = q; b.addEventListener('click', () => reply(q === 'Free quote' ? 'I want a quote' : q)); quick.appendChild(b); });
  let greeted = false;
  const open = () => { panel.hidden = false; requestAnimationFrame(() => panel.classList.remove('pre')); btn.setAttribute('aria-expanded', 'true'); if (!greeted) { greeted = true; say('Hi, I am the Adzinox assistant. Ask me about services, pricing or careers.', 'bot'); } input.focus({ preventScroll: true }); };
  const close = () => { panel.classList.add('pre'); btn.setAttribute('aria-expanded', 'false'); setTimeout(() => { panel.hidden = true; }, 250); btn.focus({ preventScroll: true }); };
  btn.addEventListener('click', () => panel.hidden ? open() : close());
  $('#chat-x').addEventListener('click', close);
  $('#chat-form').addEventListener('submit', e => { e.preventDefault(); const t = input.value.trim(); if (!t) return; input.value = ''; reply(t); });
  initChat.close = () => { if (!panel.hidden) close(); };
}

function initCookie() {
  const bar = $('#cookie'); if (store.get('adz-cookie')) return;
  setTimeout(() => { bar.hidden = false; body.classList.add('has-cookie'); }, 1600);
  const done = v => { store.set('adz-cookie', v); bar.hidden = true; body.classList.remove('has-cookie'); };
  $('#ck-yes').addEventListener('click', () => done('all'));
  $('#ck-no').addEventListener('click', () => done('essential'));
}

/* ---------- document-level events ---------- */
function initGlobalEvents() {
  document.addEventListener('click', e => {
    const t = e.target;
    const a = t.closest('a[href^="#"]');
    const svc = t.closest('[data-service]'); const prj = t.closest('[data-project]'); const post = t.closest('[data-post]');
    const act = t.closest('[data-act]'); const filt = t.closest('[data-filter]'); const plan = t.closest('[data-quote-plan]'); const apply = t.closest('[data-apply]');
    if (act) {
      if (act.dataset.act === 'close') return closeModal();
      if (act.dataset.act === 'quote') {
        const pick = act.dataset.servicePick; closeModal();
        if (pick) { const sel = $('#q-service'); const opt = [...sel.options].find(o => o.text === pick); if (opt) sel.value = opt.value || opt.text; }
        setTimeout(() => go('quote'), 280); return;
      }
    }
    if (t.closest('.m-close')) return closeModal();
    if (t === modal) return closeModal();
    if (svc) return serviceModal(svc.dataset.service);
    if (prj) return projectModal(+prj.dataset.project);
    if (post) return postModal(+post.dataset.post);
    if (filt) { $$('.filter').forEach(b => b.setAttribute('aria-pressed', b === filt)); return drawGrid(filt.dataset.filter); }
    if (apply) { const j = JOBS[+apply.dataset.apply]; $('#j-role').value = j.t; go('careers', true); setTimeout(() => $('#j-name').focus({ preventScroll: true }), 300); const f = $('#job-wrap'); f.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' }); return; }
    if (plan) {
      const msg = $('#q-msg'); if (!msg.value) msg.value = `I am interested in the ${plan.dataset.quotePlan} package.`;
    }
    if (a && !a.hasAttribute('data-wa')) {
      const id = a.getAttribute('href').slice(1);
      if (VIEWS[id]) { e.preventDefault(); if (location.hash.slice(1) === id) showView(id); else location.hash = id; return; }
      if (!id) return;
      if (document.getElementById(id) || id === 'home') {
        e.preventDefault();
        const wait = [];
        if (viewOpen) { hideView(false); wait.push(1); }
        if (!modal.hidden) closeModal();
        setTimeout(() => go(id, false), wait.length ? 700 : 0);
      }
    }
  });
  // keyboard: Enter/Space on role=button, Escape, focus trap
  document.addEventListener('keydown', e => {
    const rb = e.target.closest && e.target.closest('[role=button][tabindex]');
    if (rb && (e.key === 'Enter' || e.key === ' ') && !e.target.matches('button,a,input,select,textarea')) { e.preventDefault(); rb.click(); }
    const top = !modal.hidden ? modal : !menu.hidden ? menu : (viewOpen ? view : null);
    if (e.key === 'Escape') {
      if (!modal.hidden) closeModal();
      else if (!$('#chat').hidden) initChat.close();
      else if (!menu.hidden) initNav.close();
      else if (viewOpen) { hideView(true); }
    }
    if (e.key === 'Tab' && top) {
      const f = $$('a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])', top).filter(x => x.offsetParent !== null && !x.closest('[inert]'));
      if (!f.length) return; const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  $('#view-x').addEventListener('click', () => hideView(true));
  addEventListener('hashchange', route);
}

/* ============================================================
   5. HERO: kinetic type + Three.js scene
============================================================ */
function splitChars(el) {
  const txt = el.textContent; el.textContent = '';
  txt.split(' ').forEach((w, wi, arr) => {
    const word = document.createElement('span'); word.style.cssText = 'display:inline-block;white-space:nowrap';
    [...w].forEach(c => { const s = document.createElement('span'); s.className = 'ch'; s.textContent = c; word.appendChild(s); });
    el.appendChild(word); if (wi < arr.length - 1) el.appendChild(document.createTextNode(' '));
  });
  return $$('.ch', el);
}

let introTL = null;
function initHeroText() {
  const words = $$('#rot .rot-w');
  if (!reduce && words.length > 1) {
    let i = 0;
    setInterval(() => {
      const cur = words[i]; i = (i + 1) % words.length; const nx = words[i];
      cur.classList.remove('on'); cur.classList.add('out');
      nx.classList.remove('out'); nx.classList.add('on');
      setTimeout(() => cur.classList.remove('out'), 700);
    }, 2600);
    words[0].classList.add('on');
  }
  if (!hasGSAP || reduce) return;
  const chars = $$('.kin [data-split]').flatMap(splitChars);
  introTL = gsap.timeline({ paused: true, defaults: { ease: 'expo.out' } })
    .from('.hero-tag', { y: 20, opacity: 0, duration: .8 })
    .from(chars, { yPercent: 115, rotate: 7, opacity: 0, duration: 1.1, stagger: .03 }, '-=.5')
    .from('#rot', { yPercent: 110, opacity: 0, duration: 1.1 }, '-=.9')
    .from('.hero-sub', { y: 24, opacity: 0, duration: .9 }, '-=.7')
    .from('.hero-cta .btn', { y: 20, opacity: 0, duration: .8, stagger: .1 }, '-=.6')
    .from('#nav .nav-in', { y: -40, opacity: 0, duration: .9 }, 0.2);
}

function initHero3D() {
  const canvas = $('#hero3d');
  if (!canvas || typeof THREE === 'undefined') return;
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'low-power' }); } catch (e) { canvas.remove(); return; }
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.75));
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(55, 1, .1, 100); cam.position.z = 14;
  const group = new THREE.Group(); scene.add(group);

  // particle field
  const N = innerWidth < 700 ? 900 : 1900;
  const pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
  const c1 = new THREE.Color('#22e5ff'), c2 = new THREE.Color('#8b5cf6'), c3 = new THREE.Color('#ff2fd0'), tmp = new THREE.Color();
  for (let i = 0; i < N; i++) {
    const r = 5 + Math.random() * 13, th = Math.random() * Math.PI * 2, ph2 = Math.acos(2 * Math.random() - 1);
    pos[i * 3] = r * Math.sin(ph2) * Math.cos(th) * 1.5; pos[i * 3 + 1] = r * Math.sin(ph2) * Math.sin(th) * .8; pos[i * 3 + 2] = r * Math.cos(ph2) - 4;
    const k = Math.random(); (k < .5 ? tmp.copy(c1).lerp(c2, k * 2) : tmp.copy(c2).lerp(c3, (k - .5) * 2)); col.set([tmp.r, tmp.g, tmp.b], i * 3);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const points = new THREE.Points(g, new THREE.PointsMaterial({ size: .075, vertexColors: true, transparent: true, opacity: .9, depthWrite: false, blending: THREE.AdditiveBlending }));
  group.add(points);

  // floating wireframe geometry
  const mk = (geo, color, op) => { const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color, wireframe: true, transparent: true, opacity: op })); group.add(m); return m; };
  const ico = mk(new THREE.IcosahedronGeometry(2.3, 1), 0x22e5ff, .5);
  const knot = mk(new THREE.TorusKnotGeometry(1.05, .3, 120, 14), 0xff2fd0, .5);
  const oct = mk(new THREE.OctahedronGeometry(1.3), 0x8b5cf6, .6);
  const ring = mk(new THREE.TorusGeometry(2.1, .04, 12, 90), 0x22e5ff, .55);
  const place = () => {
    const narrow = innerWidth < 800;
    ico.position.set(narrow ? 3.2 : 6, narrow ? 3 : .6, -2); knot.position.set(narrow ? -3.6 : -7.2, narrow ? -4 : -3, -3);
    oct.position.set(narrow ? -3 : -4.8, narrow ? 5 : 3.6, -4); ring.position.set(narrow ? 2.5 : 6, narrow ? 3 : .6, -2);
    const s = narrow ? .7 : 1; [ico, knot, oct, ring].forEach(m => m.scale.setScalar(s));
  };
  const hero = $('#home');
  const resize = () => { const w = hero.clientWidth, h = hero.clientHeight; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); place(); if (reduce) renderer.render(scene, cam); };
  resize();
  'ResizeObserver' in window ? new ResizeObserver(resize).observe(hero) : addEventListener('resize', resize);

  let tx = 0, ty = 0, vis = true, t0 = performance.now();
  addEventListener('pointermove', e => { tx = (e.clientX / innerWidth - .5) * .5; ty = (e.clientY / innerHeight - .5) * .3; }, { passive: true });
  'IntersectionObserver' in window && new IntersectionObserver(es => { vis = es[0].isIntersecting; }, { threshold: 0 }).observe(hero);
  if (reduce) { renderer.render(scene, cam); return; }
  (function frame(now) {
    requestAnimationFrame(frame);
    if (!vis || document.hidden) return;
    const t = (now - t0) / 1000;
    points.rotation.y = t * .035; points.rotation.x = Math.sin(t * .15) * .06;
    ico.rotation.x = t * .22; ico.rotation.y = t * .3; ring.rotation.x = t * .35; ring.rotation.y = t * .1;
    knot.rotation.x = -t * .3; knot.rotation.y = t * .25; oct.rotation.y = t * .5; oct.rotation.z = t * .2;
    ico.position.y += (Math.sin(t) * .004); knot.position.y += Math.cos(t * .8) * .004;
    group.rotation.y += (tx - group.rotation.y) * .04; group.rotation.x += (ty - group.rotation.x) * .04;
    renderer.render(scene, cam);
  })(performance.now());
}

/* ============================================================
   6. SCROLL ANIMATION (GSAP + ScrollTrigger + Lenis)
============================================================ */
function initScroll() {
  if (!hasGSAP) return;
  gsap.registerPlugin(ScrollTrigger);
  if (!reduce) {
    root.classList.add('anim');
    if (typeof Lenis !== 'undefined') {
      lenis = new Lenis({ duration: 1.15, smoothWheel: true });
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(t => lenis.raf(t * 1000));
      gsap.ticker.lagSmoothing(0);
    }
  }
  enhance(document);

  // parallax orbs
  if (!reduce) $$('[data-parallax]').forEach(el => gsap.to(el, { yPercent: parseFloat(el.dataset.parallax) * 5, ease: 'none', scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } }));

  // counters
  $$('[data-count]').forEach(el => {
    const n = +el.dataset.count, d = +el.dataset.d, p = el.dataset.p, s = el.dataset.s;
    if (reduce) return;
    ScrollTrigger.create({ trigger: el, start: 'top 90%', once: true, onEnter: () => {
      const o = { v: 0 };
      gsap.to(o, { v: n, duration: 2.2, ease: 'power2.out', onUpdate: () => { el.textContent = p + o.v.toFixed(d) + s; } });
    } });
  });

  // process timeline
  const steps = $('#steps'), items = $$('.step', steps);
  if (reduce) { steps.style.setProperty('--p', 100); items.forEach(i => i.classList.add('on')); }
  else ScrollTrigger.create({ trigger: steps, start: 'top 80%', end: 'bottom 60%', scrub: true, onUpdate: s => {
    const pr = s.progress * 100; steps.style.setProperty('--p', pr.toFixed(1));
    items.forEach((el, i) => el.classList.toggle('on', pr >= (i / (items.length - 1)) * 100 - 1));
  } });

  // horizontal-scroll portfolio showcase (desktop, motion allowed)
  ScrollTrigger.matchMedia && gsap.matchMedia().add('(min-width: 900px) and (prefers-reduced-motion: no-preference)', () => {
    const track = $('#hs-track'); body.classList.add('hs-pinned');
    const dist = () => Math.max(0, track.scrollWidth - document.documentElement.clientWidth + 40);
    const tw = gsap.to(track, { x: () => -dist(), ease: 'none', scrollTrigger: { trigger: '#hs', pin: true, scrub: .8, start: 'top top', end: () => '+=' + dist(), invalidateOnRefresh: true } });
    return () => { body.classList.remove('hs-pinned'); tw.kill(); gsap.set(track, { clearProps: 'all' }); };
  });

  const refresh = () => ScrollTrigger.refresh();
  document.fonts && document.fonts.ready.then(refresh);
  addEventListener('load', () => setTimeout(refresh, 300));
}

/* ============================================================
   7. BOOT
============================================================ */
function boot() {
  const word = $('#pre-word');
  word.innerHTML = [...'ADZINOX'].map((c, i) => `<span style="animation-delay:${(.45 + i * .07).toFixed(2)}s">${c}</span>`).join('');

  bindConfig(); renderStatic(); renderPortfolio();
  initTheme(); initNav(); initScroll(); initCursor();
  if (!hasGSAP) enhance(document); // GSAP failed to load: still hydrate icons, lazy images and tags
  initTestimonials(); initFAQ(); initChat(); initCookie(); initGlobalEvents();
  initHeroText(); initHero3D();
  hydrateIcons(document); // static icons in markup

  bindForm($('#quote-form'), { wrap: $('#quote-wrap'), title: 'Thank you', text: 'Your request has been recorded. A strategist will review it and get back to you.' });
  bindForm($('#job-form'), { wrap: $('#job-wrap'), title: 'Application received', text: 'Thanks for applying. Our team will review your details and be in touch if there is a fit.' });
  bindForm($('#contact-form'), { wrap: $('#contact-wrap'), title: 'Message sent', text: 'Thanks for reaching out. We will reply as soon as we can.' });
  bindForm($('#news-form'), { wrap: $('#news-wrap'), title: 'You are subscribed', text: 'Watch your inbox for the next issue.', inline: true });

  // preloader
  const pre = $('#preloader'), minT = reduce ? 250 : 1900, t0 = performance.now(); let hid = false;
  const hide = () => {
    if (hid) return; hid = true; pre.classList.add('done'); setTimeout(() => pre.remove(), 700);
    introTL && introTL.play();
    const start = window.ADZ_START || location.hash.slice(1);
    if (VIEWS[start]) { if (window.ADZ_START) safe(() => history.replaceState(null, '', '#' + start)); showView(start); }
    else if (start && document.getElementById(start)) setTimeout(() => go(start, true), 200);
  };
  const ready = () => setTimeout(hide, Math.max(0, minT - (performance.now() - t0)));
  document.readyState === 'complete' ? ready() : addEventListener('load', ready);
  setTimeout(hide, 3800); // failsafe
}

boot();
})();
