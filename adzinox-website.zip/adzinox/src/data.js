/* ============================================================
   1. CONFIG  (✎ REPLACE every value marked below)
============================================================ */
const CONFIG = {
  tagline: "Where Ideas Go Viral",                      // ✎ REPLACE: your tagline
  phone: "+91 00000 00000",                            // ✎ REPLACE
  email: "hello@yourdomain.com",                       // ✎ REPLACE
  address: "Your Street Address, Your City, State PIN, India", // ✎ REPLACE
  hours: "Mon to Sat, 10:00 to 19:00 IST",
  whatsapp: "910000000000",                            // ✎ REPLACE: country code + number, digits only
  mapQuery: "Mumbai, India",                           // ✎ REPLACE: address text used by the Google Map embed
  social: {                                            // ✎ REPLACE with your profile URLs
    instagram: "https://instagram.com/",
    linkedin: "https://linkedin.com/",
    facebook: "https://facebook.com/",
    youtube: "https://youtube.com/",
    x: "https://x.com/"
  },
  formEndpoint: "",            // ✎ e.g. a Formspree / Web3Forms / your API URL. Empty = demo mode (nothing is sent).
  showPlaceholderTags: true    // set false to hide the yellow SAMPLE tags before launch
};

/* ============================================================
   2. CONTENT DATA
============================================================ */
const SECTIONS = [
  ["about", "About"], ["services", "Services"], ["process", "Process"], ["work", "Work"],
  ["results", "Results"], ["industries", "Industries"], ["clients", "Clients"], ["testimonials", "Testimonials"],
  ["team", "Team"], ["pricing", "Pricing"], ["tools", "Tools"], ["awards", "Awards"],
  ["insights", "Insights"], ["careers", "Careers"], ["faq", "FAQ"], ["quote", "Free Quote"],
  ["contact", "Contact"], ["newsletter", "Newsletter"]
];

const VALUES = [
  { ic: "bolt", t: "Bold by default", d: "Safe work is invisible. We push every brief until it has a point of view." },
  { ic: "shield", t: "Proof over opinion", d: "We test, measure and show our working. Taste matters, evidence decides." },
  { ic: "pen", t: "Craft without ego", d: "The best idea wins, wherever it comes from, and gets finished properly." },
  { ic: "heart", t: "Partners, not vendors", d: "We act like part of your team and speak up when something will not work." }
];

// ✎ REPLACE with your real company milestones
const TIMELINE = [
  ["2018", "Adzinox founded with a three-person team and a shared desk."],
  ["2019", "First ten brand partnerships across retail, food and education."],
  ["2021", "Performance marketing and social studios launched in-house."],
  ["2023", "Video production floor and OOH buying desk opened."],
  ["2025", "AI analytics lab starts powering audience and creative decisions."],
  ["2026", "Serving brands across India from multiple cities."]
];

const SERVICES = [
  { id: "brand", ic: "target", t: "Brand Strategy & Identity", s: "Positioning, naming and visual identity that make you the obvious choice.",
    tags: ["Positioning", "Naming", "Logo system", "Brand voice"],
    d: "We start with your customers and your competitors, then define what you stand for and how you sound. The result is a brand your team can use every day, from a pitch deck to a shop sign.",
    g: ["Market and audience research with a clear positioning statement", "Name, logo, colour, type and tone-of-voice guidelines", "Templates and a launch plan so the new identity rolls out cleanly"],
    r: "A brand system that your team can apply without calling us." },
  { id: "digital", ic: "trend", t: "Digital Marketing", s: "SEO, social media marketing and PPC built around revenue, not clicks.",
    tags: ["SEO", "SMM", "PPC", "Performance"],
    d: "One team runs search, social and paid media against a single scorecard. We track cost per lead and return on ad spend, shift budget weekly and report in plain numbers.",
    g: ["Technical and content SEO with monthly ranking and traffic reports", "Meta, Google and YouTube campaigns with conversion tracking set up correctly", "Landing page testing and weekly budget re-allocation"],
    r: "Lower cost per customer and a funnel you can see end to end." },
  { id: "social", ic: "chat", t: "Social Media Management", s: "Daily presence, community care and content that earns follows.",
    tags: ["Content calendar", "Community", "Reels", "Reporting"],
    d: "We plan, design, write, post and respond. Your pages get a consistent voice, a smart content calendar and a team that handles comments and DMs quickly.",
    g: ["Monthly content calendar tied to launches and festivals", "Posts, reels, stories and carousels designed and published for you", "Community replies, escalation rules and monthly insight reports"],
    r: "A page that looks alive and brings the right people in." },
  { id: "design", ic: "pen", t: "Creative Design", s: "Graphics, logos and packaging that stop the scroll and the shelf walk.",
    tags: ["Graphics", "Logo", "Packaging", "Collateral"],
    d: "Our designers work across digital and print, so your campaign looks like one idea everywhere. We handle concept, artwork and production-ready files.",
    g: ["Campaign key visuals and social, web and print adaptations", "Packaging design with dielines and printer-ready artwork", "Brochures, catalogues, decks and presentations"],
    r: "Consistent, distinctive visuals across every touchpoint." },
  { id: "video", ic: "film", t: "Video Production & Motion Graphics", s: "Brand films, ad spots, reels and animation, from script to final cut.",
    tags: ["Ad films", "Reels", "Motion", "Animation"],
    d: "Scripting, shooting, editing, sound and motion in one pipeline. We make the hero film and the cut-downs for every platform in the same shoot.",
    g: ["Concept, script, storyboard and casting", "Shoot, edit, colour, sound design and subtitles in multiple languages", "Platform cut-downs for Instagram, YouTube, TV and in-store screens"],
    r: "One shoot that feeds a full quarter of content." },
  { id: "influencer", ic: "star", t: "Influencer Marketing", s: "Creators matched to your audience, briefed well and measured honestly.",
    tags: ["Creator sourcing", "Briefing", "Whitelisting", "Tracking"],
    d: "We shortlist creators on audience fit and past results, negotiate fair rates and manage briefs, approvals and usage rights. Content can then be boosted as paid ads.",
    g: ["Creator shortlist with audience quality checks", "Contracts, briefs, approvals and posting schedule", "Tracked links, codes and a campaign performance report"],
    r: "Authentic reach with numbers you can defend internally." },
  { id: "ooh", ic: "billboard", t: "Outdoor, OOH & Print Advertising", s: "Hoardings, transit, malls and print placements bought and managed end to end.",
    tags: ["Hoardings", "Transit", "Mall & airport", "Print"],
    d: "We plan sites by footfall and audience, negotiate media rates and supervise printing and installation. Proof-of-display photos come with every flight.",
    g: ["Site selection and media planning by city and catchment", "Creative adaptation, printing and installation supervision", "Proof-of-display reports and renewal recommendations"],
    r: "Visible presence exactly where your buyers travel and shop." },
  { id: "web", ic: "code", t: "Web & App Development", s: "Fast, accessible sites and apps built to convert.",
    tags: ["Websites", "E-commerce", "Mobile apps", "CMS"],
    d: "Design and engineering together: websites, online stores and apps that load quickly, rank well and are easy for your team to update.",
    g: ["UX flows, UI design and responsive build", "Analytics, SEO foundations and speed optimisation", "Hosting, handover training and ongoing support plans"],
    r: "A digital home that turns visits into enquiries and orders." },
  { id: "content", ic: "text", t: "Content Marketing & Copywriting", s: "Words that rank, persuade and sound like a human wrote them.",
    tags: ["Blogs", "Website copy", "Scripts", "Regional languages"],
    d: "Our writers cover English, Hindi and regional languages. We plan topics from search demand and customer questions, then write pieces that build trust.",
    g: ["Content strategy and keyword-led editorial calendar", "Website, ad, email and video script copy", "Case studies, whitepapers and thought-leadership articles"],
    r: "Content that keeps bringing customers in after the campaign ends." },
  { id: "pr", ic: "megaphone", t: "Public Relations & Media Planning", s: "Earned coverage and smart paid media working as one plan.",
    tags: ["Press", "Media planning", "Crisis comms", "Events"],
    d: "We shape your story, brief journalists and plan paid media around it. When something goes wrong we help you respond clearly and quickly.",
    g: ["Press releases, media kits and journalist outreach", "Integrated media plans across TV, print, digital and radio", "Launch-event support and crisis communication playbooks"],
    r: "Credibility from coverage, reach from media, both on one plan." },
  { id: "ai", ic: "chip", t: "AI-driven Marketing & Analytics", s: "Predictive audiences, creative testing and dashboards that answer real questions.",
    tags: ["Dashboards", "Attribution", "Automation", "Creative testing"],
    d: "We connect your ad, web and sales data, then use models to find audiences, predict churn and test creative variations faster than manual workflows allow.",
    g: ["Unified reporting dashboard across ad platforms and CRM", "Audience modelling, lookalikes and budget recommendations", "Automated creative variants with structured A/B testing"],
    r: "Faster decisions, fewer wasted rupees." }
];

const STEPS = [
  { ic: "search", t: "Discover", d: "We interview stakeholders, audit your market and agree the one number that defines success." },
  { ic: "compass", t: "Strategy", d: "Audience, message, channels and budget laid out in a plan you can challenge before we build." },
  { ic: "spark", t: "Create", d: "Concepts, design, film and copy produced by one team, reviewed against the strategy." },
  { ic: "rocket", t: "Launch", d: "Tracking verified, assets scheduled and campaigns switched on across every channel." },
  { ic: "loop", t: "Optimize", d: "Weekly reads, monthly deep dives and fast reallocation. What we learn feeds the next brief." }
];

// ✎ REPLACE: sample projects. Swap the Unsplash image IDs and write real case studies.
const CATS = ["Branding", "Digital", "Video", "Print", "OOH"];
const PROJECTS = [
  { t: "Aurora Organics: Rebrand", c: "Branding", y: 2025, img: "photo-1522202176988-66273c2fd55f",
    ch: "A fast-growing organic food brand looked like a local shop while selling nationally.", so: "New positioning, logo system, packaging language and a brand voice guide applied across web and shelf.",
    res: [["+38%", "Shelf recall in surveys"], ["12", "Retail chains onboarded"], ["6 wks", "Rebrand to launch"]] },
  { t: "Novakart: Festive Sale Push", c: "Digital", y: 2025, img: "photo-1460925895917-afdab827c52f",
    ch: "An online marketplace needed record festive sales without a matching rise in acquisition cost.", so: "Full-funnel Meta and Google plan, creative testing every 48 hours and weekly budget shifts towards the best audiences.",
    res: [["4.6x", "Return on ad spend"], ["-27%", "Cost per order"], ["2.1M", "Unique buyers reached"]] },
  { t: "Urban Nest: Launch Film", c: "Video", y: 2024, img: "photo-1551288049-bebda4e38f71",
    ch: "A real-estate developer wanted a launch film that felt like a home, not a brochure.", so: "A story-led 90 second film shot on location, with six vertical cut-downs and a regional-language voice-over set.",
    res: [["1.8M", "Organic film views"], ["+64%", "Site visit bookings"], ["3 langs", "Voice-over versions"]] },
  { t: "Spice Route: Packaging Range", c: "Print", y: 2024, img: "photo-1486312338219-ce68d2c6f44d",
    ch: "A spice brand wanted a premium range without losing its heritage audience.", so: "A flavour-coded packaging system with illustrated botanicals, tested with shoppers before print.",
    res: [["+22%", "Premium range sales"], ["9 SKUs", "Launched together"], ["0", "Print reworks"]] },
  { t: "Velocity Motors: City Takeover", c: "OOH", y: 2025, img: "photo-1553877522-43269d4ea984",
    ch: "A mobility brand needed to own attention in five cities in one launch month.", so: "Hoardings at traffic nodes, transit wraps and mall activations with one QR path to test-drive booking.",
    res: [["5", "Cities covered"], ["11,400", "QR test-drive scans"], ["+31%", "Showroom footfall"]] },
  { t: "BrightPath Academy: Admissions Drive", c: "Digital", y: 2024, img: "photo-1542744173-8e7e53415bb0",
    ch: "A school group had a short admissions window and a tight budget.", so: "Hyper-local search and social ads, WhatsApp lead follow-up and parent testimonial reels.",
    res: [["2.3x", "More qualified enquiries"], ["-35%", "Cost per enquiry"], ["96%", "Seats filled"]] },
  { t: "Kaya Wellness: Brand Identity", c: "Branding", y: 2026, img: "photo-1557804506-669a67965ba0",
    ch: "A wellness start-up had a strong product and a forgettable look.", so: "A calm, confident identity with motion language, app icon set and a social template library.",
    res: [["+54%", "Profile visits"], ["3x", "Faster content production"], ["1", "Consistent look everywhere"]] },
  { t: "Trailhead Travel: Reels Series", c: "Video", y: 2026, img: "photo-1531297484001-80022131f5a1",
    ch: "A travel company needed steady short-form content without repeating itself.", so: "A twelve-episode reels format with local creators, shot in batches and edited for each platform.",
    res: [["12", "Episodes in one shoot"], ["+210%", "Follower growth"], ["8.5%", "Average engagement"]] },
  { t: "Metro Mart: Hoarding Network", c: "OOH", y: 2025, img: "photo-1504384308090-c894fdcc538d",
    ch: "A retail chain wanted to be the first name people think of near each store.", so: "A site-by-site plan around each store's catchment, with weekly offer swaps and proof-of-display tracking.",
    res: [["38", "Sites managed"], ["+18%", "Store visits"], ["100%", "Proof-of-display coverage"]] }
];

// ✎ REPLACE: sample figures
const STATS = [
  { n: 450, p: "", s: "+", l: "Projects delivered", d: 0 },
  { n: 120, p: "", s: "+", l: "Brands served", d: 0 },
  { n: 85, p: "₹", s: " Cr+", l: "Ad spend managed", d: 0 },
  { n: 4.2, p: "", s: "x", l: "Average return on ad spend", d: 1 },
  { n: 18, p: "", s: "", l: "Industry awards", d: 0 }
];

const INDUSTRIES = [
  ["cart", "E-commerce & D2C"], ["bag", "Retail"], ["fork", "Food & Beverage"], ["health", "Healthcare & Wellness"],
  ["cap", "Education"], ["building", "Real Estate"], ["rupee", "Banking & Finance"], ["chip", "Tech & SaaS"],
  ["car", "Automotive"], ["shirt", "Fashion & Lifestyle"], ["plane", "Travel & Hospitality"], ["tv", "Media & Entertainment"]
];

// ✎ REPLACE: sample client names. Use real client logos you have permission to show.
const CLIENTS = ["NOVAKART", "Aurora Organics", "Urban Nest", "Spice Route", "Velocity Motors", "BrightPath", "Kaya Wellness", "Trailhead", "Metro Mart", "Lumen Labs", "Saffron & Co.", "Orbit Fitness"];

// ✎ REPLACE: sample testimonials and portraits
const TESTIMONIALS = [
  { q: "They rebuilt our brand and our funnel in one quarter. For the first time our creative and our media numbers tell the same story.", n: "Priya Nair", r: "Founder, Aurora Organics", img: "photo-1494790108377-be9c29b29330" },
  { q: "Adzinox treated our festive budget like their own. Weekly reports were clear, and the team moved money the moment something worked.", n: "Rahul Khanna", r: "Head of Growth, Novakart", img: "photo-1507003211169-0a1dd7228f2d" },
  { q: "The launch film felt like our buyers' lives, not a brochure. Site visits jumped and sales finally had warm leads to call.", n: "Meera Joshi", r: "Marketing Director, Urban Nest", img: "photo-1573164713714-d95e436ab8d6" },
  { q: "We hired them for hoardings and stayed for everything else. One team, one plan, no finger-pointing between vendors.", n: "Arjun Malhotra", r: "COO, Velocity Motors", img: "photo-1500648767791-00dcc994a43e" }
];

// ✎ REPLACE: sample team
const TEAM = [
  { n: "Aarav Mehta", r: "Founder & CEO", img: "photo-1560250097-0b93528c311a" },
  { n: "Isha Kapoor", r: "Creative Director", img: "photo-1438761681033-6461ffad8d80" },
  { n: "Rohan Iyer", r: "Head of Performance", img: "photo-1472099645785-5658abf4ff4e" },
  { n: "Neha Sharma", r: "Strategy Lead", img: "photo-1580489944761-15a19d654956" }
];

// ✎ REPLACE: sample pricing in INR
const PLANS = [
  { n: "Starter", a: "₹49,999", per: "/ month", d: "For young brands finding their voice online.", f: ["Social media management, 12 posts a month", "Basic brand kit and templates", "One paid channel, up to ₹1 lakh managed spend", "Monthly performance report"] },
  { n: "Growth", a: "₹1,29,999", per: "/ month", hot: true, d: "For brands ready to scale across channels.", f: ["Everything in Starter", "SEO, Meta and Google ads, full funnel", "2 short videos or reels a month", "Landing page testing and CRO", "Weekly calls and live dashboard"] },
  { n: "Enterprise", a: "Custom", per: "", d: "For multi-brand, multi-city or always-on programmes.", f: ["Dedicated pod of strategist, creative and media lead", "OOH, PR and brand film production", "AI analytics and custom reporting", "Quarterly planning workshops"] }
];

const TOOLS = [["Meta Ads", "M"], ["Google Ads", "G"], ["GA4", "GA"], ["Adobe CC", "Ad"], ["Figma", "Fi"], ["After Effects", "Ae"], ["DaVinci Resolve", "DR"], ["Semrush", "Se"], ["HubSpot", "Hs"], ["Shopify", "Sh"], ["WordPress", "Wp"], ["Looker Studio", "Ls"], ["Notion", "No"], ["Slack", "Sl"]];

// ✎ REPLACE: sample awards
const AWARDS = [
  ["Best Digital Campaign", "Awards body name, 2025"],
  ["Performance Agency of the Year", "Awards body name, 2025"],
  ["Google Partner", "Add your certification badge"],
  ["Meta Business Partner", "Add your certification badge"],
  ["ISO 9001 Certified", "Add certificate number"],
  ["Great Place to Work", "Add year"]
];

// ✎ REPLACE: sample articles
const POSTS = [
  { t: "Why your cost per lead is lying to you", cat: "Performance", date: "Oct 14, 2026", min: 6, img: "photo-1460925895917-afdab827c52f",
    x: "A low cost per lead feels like a win until sales tells you nobody picks up. We look at what to track instead.",
    b: ["Cost per lead is easy to lower. Target a broader audience, make the offer vague, and the number drops. The problem shows up two weeks later when your sales team spends its day chasing people who never wanted the product.", "Track cost per qualified lead and cost per sale. Push CRM outcomes back into your ad platforms so the algorithms learn from real buyers. Expect your headline cost to rise at first and your revenue per rupee to follow."] },
  { t: "Hoardings in the age of QR codes", cat: "OOH", date: "Sep 29, 2026", min: 5, img: "photo-1553877522-43269d4ea984",
    x: "Outdoor can be measured now. A practical guide to tying a billboard to a booking.",
    b: ["A hoarding used to be a leap of faith. With a short URL, a unique QR code per site and a dedicated landing page, you can compare locations by scans and conversions within days.", "Keep the code large, the offer simple and the page fast on mobile. Rotate creatives weekly and let the data tell you which sites deserve a renewal."] },
  { t: "Short video that sells: a 5-part script formula", cat: "Video", date: "Sep 12, 2026", min: 7, img: "photo-1531297484001-80022131f5a1",
    x: "Hook, problem, proof, offer, action. How we structure 30-second ads that people actually finish.",
    b: ["The first two seconds decide everything. Open on the result or the problem, never on a logo. Show proof quickly: a number, a face, a before and after.", "End with one clear action. Test three hooks against the same body, because the hook is where most videos win or lose."] },
  { t: "SEO for Indian languages: where to start", cat: "SEO", date: "Aug 30, 2026", min: 6, img: "photo-1498050108023-c5249f4df085",
    x: "Search in Hindi and regional languages is growing fast. Here is how to prepare your site.",
    b: ["Search habits differ by language. Many people mix scripts or type in Roman letters. Research real queries, not translations of your English keywords.", "Use proper language tags, fast pages and native writers. Start with five high-intent pages, measure, then expand."] },
  { t: "How to brief an agency so you get better work", cat: "Strategy", date: "Aug 14, 2026", min: 5, img: "photo-1522202176988-66273c2fd55f",
    x: "A one-page brief template that saves two rounds of revisions.",
    b: ["Great work needs a clear problem. Tell us who you want to reach, what you want them to do, what stops them today, and how you will measure success.", "Share budget range and constraints early. They are not limits on creativity, they are the shape of it."] },
  { t: "Using AI in creative testing without losing your brand", cat: "AI", date: "Jul 28, 2026", min: 8, img: "photo-1551288049-bebda4e38f71",
    x: "Generate more variants, keep the voice. Our guardrails for AI-assisted ads.",
    b: ["AI can produce fifty headline variants in minutes. It cannot decide which ones sound like you. Start with a tight brand voice guide and a human approval step.", "Test in small batches, retire losers quickly and feed the winners back into the next round. Speed helps only when the brand stays recognisable."] }
];

// ✎ REPLACE: real openings
const JOBS = [
  { t: "Senior Performance Marketer", ty: "Full-time", lo: "Hybrid", ex: "4+ years" },
  { t: "Creative Designer (Brand & Social)", ty: "Full-time", lo: "On-site", ex: "2+ years" },
  { t: "Video Editor & Motion Artist", ty: "Full-time", lo: "On-site", ex: "3+ years" },
  { t: "Account Manager", ty: "Full-time", lo: "Hybrid", ex: "3+ years" },
  { t: "Copywriter (English & Hindi)", ty: "Full-time", lo: "Remote", ex: "2+ years" },
  { t: "Front-end Developer", ty: "Full-time", lo: "Hybrid", ex: "2+ years" }
];

const FAQS = [
  ["What does Adzinox actually do?", "We are a full-service advertising agency. Brand strategy, creative design, video, social media, performance marketing, influencer campaigns, outdoor advertising, web development, PR and AI-driven analytics are all handled by one team."],
  ["How much budget do I need to start?", "Our Starter package begins at a modest monthly retainer, and ad spend is separate. During the free consultation we will tell you honestly what your goal needs and where to begin if the budget is small."],
  ["Do you work with small businesses and start-ups?", "Yes. About half of our clients started with us as early-stage brands. We build packages that can grow with you."],
  ["How long until I see results?", "Paid campaigns usually show signal within 2 to 4 weeks. SEO and brand building take 3 to 6 months. We set expectations for each channel in writing before we begin."],
  ["Who owns the creative work and ad accounts?", "You do. Ad accounts are created in your name, and final creative files are handed over when invoices are cleared."],
  ["Can you run campaigns in regional languages?", "Yes. We write, design and produce in English, Hindi and several regional languages, with native reviewers for each."],
  ["How do you report performance?", "A live dashboard, a weekly summary and a monthly review call. We report in business terms: leads, sales, cost per customer and return on spend."]
];
